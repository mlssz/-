package service;

import java.util.List;

import dao.Line;

public interface lineService {
	public List<Line> getAllLineByUserId(Line l);
	public Line getaLineById(Line l);
	public boolean deleteaLineById(Line l);
	public boolean updateaLineById(Line l);
	public boolean insertaLine(Line l);
}

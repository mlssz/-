package controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import dao.Order;
import service.orderService;

@Controller
@RequestMapping("order")
public class orderController {

	@Autowired
	private orderService os;
	
	@RequestMapping("getOneById")
	public Map<String, Object> getOneById(
			@RequestParam("id") int id
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Order o = new Order();
		o.setId(id);
		o = os.getOneById(o);
		if (o != null) {
			json.put("status", 1);
			json.put("order", o);
		} else {
			json.put("status", 0);
			json.put("msg", "没有相关信息");
		}
		return json;
	}
	
	@RequestMapping("getRentalAll")
	public Map<String, Object> getRentalAll(
			@RequestParam("uid") int rental
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Order o = new Order();
		o.setRental(rental);
		List<Order> lo = null;
		lo = os.getRentalAll(o);
		if (lo != null) {
			json.put("status", 1);
			json.put("order", lo);
		} else {
			json.put("status", 0);
			json.put("msg", "没有相关信息");
		}
		return json;
	}
	
	@RequestMapping("getLesseeAll")
	public Map<String, Object> getLesseeAll(
			@RequestParam("uid") int lessee
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Order o = new Order();
		o.setLessee(lessee);
		List<Order> lo = null;
		lo = os.getLesseeAll(o);
		if (lo != null) {
			json.put("status", 1);
			json.put("order", lo);
		} else {
			json.put("status", 0);
			json.put("msg", "没有相关信息");
		}
		return json;
	}
	
	@RequestMapping("createOne")
	public Map<String, Object> createOne(
			@RequestParam("uid") int rental,
			@RequestParam("startplace") String startplace,
			@RequestParam("startplacex") int startplacex,
			@RequestParam("startplacey") int startplacey,
			@RequestParam("endplace") String endplace,
			@RequestParam("starttime") long starttime,
			@RequestParam("status") int status,
			@RequestParam("trucktype") int trucktype,
			@RequestParam("fee") double fee
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Order o = new Order();
		o.setRental(rental);
		o.setStartplace(startplace);
		o.setStartplacex(startplacex);
		o.setStartplacey(startplacey);
		o.setEndplace(endplace);
		o.setFee(fee);
		o.setStarttime(new Timestamp(starttime));
		o.setStatus(status);
		o.setTrucktype(trucktype);
		o = os.insertOneOrder(o);
		if (o != null) {
			json.put("status", 1);
			json.put("order", o);
		} else {
			json.put("status", 0);
			json.put("msg", "插入数据失败");
		}
		return json;
	}
	
	@RequestMapping("getNearAll")
	public Map<String, Object> getNearAll(
			@RequestParam("uid") int rental,
			@RequestParam("radius") int fee,
			@RequestParam("placex") int startplacex,
			@RequestParam("placey") int startplacey
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Order o = new Order();
		o.setStartplacex(startplacex);
		o.setStartplacey(startplacey);
		o.setFee(fee);
		List<Order> lo = os.getNearAll(o);
		if (lo.isEmpty()) {
			json.put("status", 0);
			json.put("msg", "查找失败");
		} else {
			json.put("status", 1);
			json.put("orders", lo);
		}
		return json;
	}
	
	@RequestMapping("lesseechoose")
	public Map<String, Object> lesseechoose(
			@RequestParam("uid") int lessee,
			@RequestParam("orderid") int id
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Order o = new Order();
		o.setLessee(lessee);
		o.setId(id);
		o.setAccepttime(new Timestamp(System.currentTimeMillis()));
		o.setStatus(3);
		String b = os.lesseechoose(o);
		if (b == null) {
			json.put("status", 1);
		} else {	
			json.put("status", 0);
			json.put("msg", b);
		}
		return json;
	}

	@RequestMapping("rentchoose")
	public Map<String, Object> rentchoose(
			@RequestParam("uid") int lessee,
			@RequestParam("orderid") int id
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Order o = new Order();
		o.setLessee(lessee);
		o.setId(id);
		o.setAccepttime(new Timestamp(System.currentTimeMillis()));
		o.setStatus(3);
		String b = os.rentchoose(o);
		if (b == null) {
			json.put("status", 1);
		} else {	
			json.put("status", 0);
			json.put("msg", b);
		}
		return json;
	}
	
	@RequestMapping("rentchoosestatus")
	public Map<String, Object> rentchoosestatus(
			@RequestParam("uid") int rent,
			@RequestParam("orderid") int id
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Order o = new Order();
		o.setRental(rent);
		o.setId(id);
		Set<String> lessees = os.rentchoosestatus(o);
		if (lessees != null) {
			json.put("status", 1);
			json.put("lessees", lessees);
		} else {	
			json.put("status", 0);
			json.put("msg", "没有相关记录");
		}
		return json;
	}
	
	@RequestMapping("rentchoosealessee")
	public Map<String, Object> rentchoosealessee(
			@RequestParam("uid") int rent,
			@RequestParam("orderid") int id,
			@RequestParam("lessee") int lessee
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Order o = new Order();
		o.setRental(rent);
		o.setLessee(lessee);
		o.setId(id);
		o.setStatus(3);
		o.setAccepttime(new Timestamp(System.currentTimeMillis()));
		String lessees = os.rentchoosealessee(o);
		if (lessees == null) {
			json.put("status", 1);
		} else {	
			json.put("status", 0);
			json.put("msg", lessees);
		}
		return json;
	}
	
	@RequestMapping("confirmOne")
	public Map<String, Object> confirmOne(
			@RequestParam("orderid") int id,
			@RequestParam("uid") int rental,
			@RequestParam("score") int score,
			@RequestParam("remark") String remark
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Order o = new Order();
		o.setId(id);
		o.setRental(rental);
		o.setScore(score);
		o.setRemark(remark);
		o.setEndtime(new Timestamp(System.currentTimeMillis()));
		o.setFinishtime(new Timestamp(System.currentTimeMillis()));
		o.setStatus(4);
		boolean b = os.confirmOne(o);
		if (b) {
			json.put("status", 1);
		} else {
			json.put("status", 0);
			json.put("msg", "数据未同步,操作失败");
		}
		return json;
	}

	public orderService getOs() {
		return os;
	}

	public void setOs(orderService os) {
		this.os = os;
	}
}

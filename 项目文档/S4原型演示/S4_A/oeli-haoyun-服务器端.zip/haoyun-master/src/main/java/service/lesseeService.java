package service;

import dao.Lessee;

public interface lesseeService {
	
	public Lessee getLessee(Lessee l);
	
	public Lessee getLesseeByaccountandpasswd(Lessee l);
	
	public Lessee updateLesseeById(Lessee l);

}

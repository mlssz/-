package serviceimpl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import dao.Line;
import service.lineService;

@Scope("prototype")
@Service("lineServiceImpl")
public class lineServiceImpl implements lineService {

	@Autowired
	private SqlSessionFactory ssf;

	public List<Line> getAllLineByUserId(Line l) {
		List<Line> ls = null;
		SqlSession session = ssf.openSession();
		try {
			ls = session.selectList("getAllLineByUserId", l);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return ls;
	}

	public Line getaLineById(Line l) {
		SqlSession session = ssf.openSession();
		List<Line> ls = null;
		try {
			ls = session.selectList("getaLineById", l);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (ls.isEmpty()) {
			return null;
		} else {
			return ls.get(0);
		}
	}

	public boolean deleteaLineById(Line l) {
		SqlSession session = ssf.openSession();
		int mark = 0;
		try {
			mark = session.delete("deleteaLineById",l);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (mark > 0)
			return true;
		else
			return false;
	}

	public boolean updateaLineById(Line l) {
		SqlSession session = ssf.openSession();
		int mark = 0;
		try {
			mark = session.update("updateaLineById",l);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (mark > 0)
			return true;
		else
			return false;
	}

	public boolean insertaLine(Line l) {
		SqlSession session = ssf.openSession();
		int mark = 0;
		try {
			mark = session.insert("insertaLine",l);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (mark > 0)
			return true;
		else
			return false;
	}

	public SqlSessionFactory getSsf() {
		return ssf;
	}

	public void setSsf(SqlSessionFactory ssf) {
		this.ssf = ssf;
	}

}

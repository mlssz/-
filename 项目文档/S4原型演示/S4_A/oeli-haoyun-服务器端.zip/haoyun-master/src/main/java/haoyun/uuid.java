package haoyun;

import java.util.Random;
import java.util.UUID;

public class uuid {

	public static void main(String[] args) {
		System.out.println(UUID.randomUUID().toString().replaceAll("-", "").substring(0, 6));
		Random r = new Random(System.currentTimeMillis());
		for (int i = 0; i < 10; i++) {
			System.out.println(Math.abs(r.nextInt())%10);
		}
	}

}

package haoyun;

import java.sql.Timestamp;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.Rental;

public class hello {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				new String[] { "applicationContent.xml" });
		SqlSessionFactory sf = (SqlSessionFactory) context.getBean("sqlSessionFactory");
		SqlSession session = sf.openSession();
		Rental rent = new Rental();
		rent.setAccount("177645");
		rent.setLastlogin(new Timestamp(System.currentTimeMillis()));
		rent.setRegistTime(new Timestamp(System.currentTimeMillis()));
		rent.setName("无名");
		rent.setType(1);
		rent.setScore(0);
		rent.setToken("dsfdsfsdfsdfsdfsdfsdfsdfsdftewrtwerwerwer");
		try {
			System.out.println(session.insert("insertarent", rent));
			System.out.println(session.insert("insertarentposition1584965020" + "", rent));
		} finally {
			session.close();
		}
		context.close();
	}
}

package service;

import java.util.List;

import dao.Truck;

public interface truckService {
	public Truck addaTruck(Truck t);
	public List<Truck> findMyTruck(Truck t);
}

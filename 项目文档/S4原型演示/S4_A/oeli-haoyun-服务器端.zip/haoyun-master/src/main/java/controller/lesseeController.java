package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import dao.Lessee;
import dao.Truck;
import redis.clients.jedis.ShardedJedisPool;
import serviceimpl.lesseeServiceImpl;
import serviceimpl.truckServiceImpl;

@Controller
@RequestMapping("lessee")
public class lesseeController {

	@Autowired
	private lesseeServiceImpl lci;
	
	@Autowired
	private truckServiceImpl tsi;
	
	@Autowired
	private ShardedJedisPool shardedJedisPool;

	public lesseeServiceImpl getLci() {
		return lci;
	}

	public void setLci(lesseeServiceImpl lci) {
		this.lci = lci;
	}
	
	public truckServiceImpl getTsi() {
		return tsi;
	}

	public void setTsi(truckServiceImpl tsi) {
		this.tsi = tsi;
	}

	@RequestMapping("regist")
	public Map<String, Object> regist(
			@RequestParam(value = "phone") String phone,
			@RequestParam(value = "password") String password, 
			@RequestParam(value = "positionx") double positionx,
			@RequestParam(value = "positiony") double positiony,
			@RequestParam(value = "code") String code
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		String s = shardedJedisPool.getResource().get(phone+"regist");
		if (s == null || !s.equals(code)) {
			json.put("status", 0);
			json.put("msg", "验证码错误");
		} else {
			if (phone == null || password == null || phone.length() != 11 || password.length() < 6) {
				json.put("status", 0);
				json.put("msg", "数据格式不符合要求！");
			} else {
				String token = UUID.randomUUID().toString().replaceAll("-", "")
						+ UUID.randomUUID().toString().replaceAll("-", "");
				Lessee le = new Lessee();
				le.setAccount(phone);
				le.setCi("");
				le.setLastlogin(new Timestamp(System.currentTimeMillis()));
				le.setRegistTime(new Timestamp(System.currentTimeMillis()));
				le.setToken(token);
				le.setName("无名");
				le.setPassword(password);
				le.setPositionX(positionx);
				le.setPositionY(positiony);
				le.setRealName("");
				le.setScore(0);
				le.setType(4);
				le = lci.getLessee(le);
				if (le == null) {
					json.put("status", 0);
					json.put("msg", "未知错误！");
				} else if(le.getType() < 1) {
					json.put("status", 0);
					json.put("msg", "用户已经注册！请登陆！");
				} else {
					le.setPassword("");
					json.put("status", 1);
					json.put("lessee", le);
				}
			}
		}
		return json;
	}
	
	@RequestMapping("/login")
	public Map<String, Object> login(
			@RequestParam(value = "phone") String phone,
			@RequestParam(value = "password") String password, 
			@RequestParam(value = "positionx") double positionx,
			@RequestParam(value = "positiony") double positiony
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		if (phone == null || password == null || phone.length() != 11 || password.length() < 6) {
			json.put("status", 0);
			json.put("msg", "数据格式不符合要求！");
		} else {
			String token = UUID.randomUUID().toString().replaceAll("-", "")
					+ UUID.randomUUID().toString().replaceAll("-", "");
			Lessee le = new Lessee();
			le.setLastlogin(new Timestamp(System.currentTimeMillis()));
			le.setToken(token);
			le.setAccount(phone);
			le.setPassword(password);
			le.setPositionX(positionx);
			le.setPositionY(positiony);
			le = lci.getLesseeByaccountandpasswd(le);
			if (le == null) {
				json.put("status", 0);
				json.put("msg", "用户不存在！");
			} else if (le.getType() < 0) {
				json.put("status", 0);
				json.put("msg", "密码错误！");
			}  else {
				le.setPassword("");
				json.put("status", 1);
				json.put("lessee", le);
			}
		}
		return json;
	}

	@RequestMapping("finishmyinfo")
	public Map<String, Object> finishmyinfo(
			@RequestParam(value = "uid") int uid,
			@RequestParam(value = "nickname") String nickname,
			@RequestParam(value = "realname") String realname,
			@RequestParam(value = "ci") String ci
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Lessee l = new Lessee();
		l.setId(uid);
		l.setName(nickname);
		l.setRealName(realname);
		l.setCi(ci);
		if (l.getName() == null || l.getRealName() == null || l.getCi() == null || l.getRealName().length() < 1 || l.getName().length() < 1 || l.getCi().length() != 18 || uid < 0 ) {
			json.put("status", 0);
			json.put("msg", "数据格式不正确！");
		} else {
			l = lci.updateLesseeById(l);
			if (l != null)
				l.setPassword("");
			json.put("status", 1);
			json.put("lessee", l);
		}
		return json;
	}
	
	@RequestMapping("addatruck")
	public Map<String, Object> addatruck(
			@RequestParam(value="uid") int uid,
			@RequestParam(value="no") String no,
			@RequestParam(value="load") double load,
			@RequestParam(value="width") double width,
			@RequestParam(value="height") double height,
			@RequestParam(value="length") double length,
			@RequestParam(value="type") int type,
			@RequestParam(value="moreinfo") String moreinfo,
			@RequestParam(value="remark") String remark
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Truck t = new Truck();
		t.setLessee(uid);
		t.setNo(no);
		t.setLoads(load);
		t.setWidth(width);
		t.setHeight(height);
		t.setLength(length);
		t.setType(type);
		t.setMoreinfo(moreinfo);
		t.setRemark(remark);
		t = tsi.addaTruck(t);
		if (t == null) {
			json.put("status", 0);
			json.put("msg", "未知错误！");
		} else {
			json.put("status", 1);
		}
		return json;
	}
	
	@RequestMapping("findmytrucks")
	public Map<String, Object> findmytrucks(
			@RequestParam(value="uid") int uid
			) {
		Map<String, Object> json = new HashMap<String, Object>();
		Truck t = new Truck();
		t.setLessee(uid);
		List<Truck> ls = tsi.findMyTruck(t);
		if (ls == null) {
			json.put("status", 0);
			json.put("msg", "未知错误！");
		} else {
			json.put("status", 1);
			json.put("trucks", ls);
		}
		return json;
	}
	
	@RequestMapping("upload")
	public Map<String,Object> upload(@RequestParam("file") MultipartFile file, @RequestParam("uid") String uid, @RequestParam("type") String type, HttpServletRequest request) {
		Map<String,Object> map = new HashMap<String, Object>();
		String filePath = request.getSession().getServletContext().getRealPath("/") + "upload/"+type+"/"+uid;
		System.out.println(filePath);
		System.out.println(file.getOriginalFilename());
		if (!file.isEmpty()){
			try {
				file.transferTo(new File(filePath));
				map.put("status", 1);
			} catch (IllegalStateException e) {
				map.put("status", 0);
				map.put("msg", "上传出错！\n"+e.toString());
				e.printStackTrace();
			} catch (IOException e) {
				map.put("status", 0);
				map.put("msg", "上传出错！\n"+e.toString());
				e.printStackTrace();
			}
		} else {
			map.put("status", 0);
			map.put("msg", "上传文件为空！");
		}
		return map;
	}
	
	@RequestMapping("download")
	public void download(@RequestParam("uid") String uid, @RequestParam("type") String type, HttpServletRequest request, HttpServletResponse response) {
		response.setCharacterEncoding("utf-8");
		try {
			// 文件保存路径
			String filePath = request.getSession().getServletContext().getRealPath("/") + "upload/"+type+"/"+uid;
			File file = new File(filePath);
			if (!file.exists()) {
				filePath = request.getSession().getServletContext().getRealPath("/") + "upload/"+type+"/0";
				file = new File(filePath);
			}
			Path path = Paths.get(file.getAbsolutePath());
			response.setContentType(Files.probeContentType(path));
			response.setHeader("Content-Disposition", "attachment;filename=" + file.getName());
			response.addHeader("Content-Length", "" + file.length());
			InputStream inputStream = new FileInputStream(file);
			System.out.println(file);
			OutputStream os = response.getOutputStream();
			byte[] b = new byte[1024];
			int length;
			while ((length = inputStream.read(b)) > 0) {
				os.write(b, 0, length);
			}
			inputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}
}

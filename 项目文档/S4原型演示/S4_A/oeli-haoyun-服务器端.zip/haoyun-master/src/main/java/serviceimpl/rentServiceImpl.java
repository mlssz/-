package serviceimpl;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import dao.Rental;
import service.rentService;

@Scope("prototype")
@Service("rentServiceImpl")
public class rentServiceImpl implements rentService {
	
	@Autowired
	private Rental rent;
	
	@Autowired
	private SqlSessionFactory ssf;
	
	public Rental getRent() {
		return rent;
	}

	public void setRent(Rental rent) {
		this.rent = rent;
	}

	public SqlSessionFactory getSsf() {
		return ssf;
	}

	public void setSsf(SqlSessionFactory ssf) {
		this.ssf = ssf;
	}


	public Rental getRentalByAccount(String account) {
		SqlSession session = ssf.openSession();
		try{
			rent = session.selectOne("getarentalbyaccount", account);
		} finally {
			session.close();
		}
		return rent;
	}

	public boolean updateRentLoginTime(Rental rent) {
		SqlSession session = ssf.openSession();
		try{
			session.update("updatearentlastlogin",rent);
			session.update("updaterentposition",rent);
			session.commit();
		} catch(Exception e){ 
			e.printStackTrace();
			return false;
		} finally {
			session.close();
		}
		return true;
	}

	public Rental insertaRent(Rental rent) {
		SqlSession session = ssf.openSession();
		try{
			session.insert("insertarent",rent);
			session.selectOne("getarentalbyaccount", rent);
			session.insert("insertarentposition",rent);
			session.commit();
		}catch(Exception e){
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
		return rent;
	}
	
}

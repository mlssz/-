package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import dao.Rental;
import redis.clients.jedis.ShardedJedisPool;
import service.rentService;
import utils.check;

@Controller
@RequestMapping("rent")
public class rentController {

	@Autowired
	private rentService rs;

	public rentService getRs() {
		return rs;
	}

	public void setRs(rentService rs) {
		this.rs = rs;
	}
	@Autowired
	private ShardedJedisPool shardedJedisPool;

	@RequestMapping("login")
	public Map<String, Object> login(
			@RequestParam(value = "account") String account,
			@RequestParam(value = "position") String position,
			@RequestParam(value = "code") String code
			) {
		Map<String, Object> map = new HashMap<String, Object>();
		String s = shardedJedisPool.getResource().get(account+"login");
		if (s == null || !s.equals(code)) {
			map.put("status", 0);
			map.put("msg", "验证码错误");
		} else {
			if (account != null && account.length() == 11 && check.isNumeric(account)) {
				String token = UUID.randomUUID().toString().replaceAll("-", "")
						+ UUID.randomUUID().toString().replaceAll("-", "");
				String[] positions = position.split(",", 0);
				Rental r = rs.getRentalByAccount(account);
				if (r == null) {
					r = new Rental();
					r.setAccount(account);
					r.setName("无名");
					r.setRegistTime(new Timestamp(System.currentTimeMillis()));
					r.setLastlogin(new Timestamp(System.currentTimeMillis()));
					r.setScore(0);
					r.setType(1);
					r.setPositionX(Double.parseDouble(positions[0]));
					r.setPositionY(Double.parseDouble(positions[1]));
					r.setToken(token);
					r = rs.insertaRent(r);
					if (r == null) {
						map.put("status", 0);
						map.put("msg", "服务器未知错误");
					} else {
						map.put("status", 1);
						map.put("rental", r);
					}
				} else {
					r.setToken(token);
					r.setPositionX(Double.parseDouble(positions[0]));
					r.setPositionY(Double.parseDouble(positions[1]));
					rs.updateRentLoginTime(r);
					map.put("status", 1);
					map.put("rental", r);
				}
			} else {
				map.put("status", 0);
				map.put("msg", "请正确输入11位电话号码");
			}
		}
		return map;
	}
	
	@RequestMapping("findnearlessee")
	public Map<String, Object> findnearlessee(@RequestParam(value = "account") String account,
			@RequestParam(value = "position") String position) {
		Map<String, Object> map = new HashMap<String, Object>();
		
		return map;
	}
	
	@RequestMapping("upload")
	public Map<String,Object> upload(@RequestParam("file") MultipartFile file, @RequestParam("uid") String uid, @RequestParam("type") String type, HttpServletRequest request) {
		Map<String,Object> map = new HashMap<String, Object>();
		String filePath = request.getSession().getServletContext().getRealPath("/") + "upload/"+type+"/"+uid;
		if (!file.isEmpty()){
			try {
				file.transferTo(new File(filePath));
				map.put("status", 1);
			} catch (IllegalStateException e) {
				map.put("status", 0);
				map.put("msg", "上传出错！");
				e.printStackTrace();
			} catch (IOException e) {
				map.put("status", 0);
				map.put("msg", "上传出错！");
				e.printStackTrace();
			}
		} else {
			map.put("status", 0);
			map.put("msg", "上传文件为空！");
		}
		return map;
	}
	
	@RequestMapping("download")
	public void download(@RequestParam("uid") String uid, @RequestParam("type") String type, HttpServletRequest request, HttpServletResponse response) {
		response.setCharacterEncoding("utf-8");
		try {
			// 文件保存路径
			String filePath = request.getSession().getServletContext().getRealPath("/") + "upload/"+type+"/"+uid;
			File file = new File(filePath);
			if (!file.exists()) {
				filePath = request.getSession().getServletContext().getRealPath("/") + "upload/"+type+"/0";
				file = new File(filePath);
			}
			Path path = Paths.get(file.getAbsolutePath());
			response.setContentType(Files.probeContentType(path));
			response.setHeader("Content-Disposition", "attachment;filename=" + file.getName());
			response.addHeader("Content-Length", "" + file.length());
			InputStream inputStream = new FileInputStream(file);
			System.out.println(file);
			OutputStream os = response.getOutputStream();
			byte[] b = new byte[1024];
			int length;
			while ((length = inputStream.read(b)) > 0) {
				os.write(b, 0, length);
			}
			inputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}
}

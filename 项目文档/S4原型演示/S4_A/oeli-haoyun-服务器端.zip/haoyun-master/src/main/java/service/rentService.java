package service;

import dao.Rental;

public interface rentService {
	public Rental getRentalByAccount(String account);

	public boolean updateRentLoginTime(Rental rent);

	public Rental insertaRent(Rental rent);
}

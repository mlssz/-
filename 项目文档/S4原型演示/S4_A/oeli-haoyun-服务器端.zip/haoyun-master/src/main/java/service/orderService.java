package service;

import java.util.List;
import java.util.Set;

import dao.Order;

public interface orderService {
	public Order getOneOrder(Order o);
	public List<Order> getOneUserAllOrders(Order o);
	public Order insertOneOrder(Order o);
	public boolean updateOneOrder(Order o);
	public boolean deleteOneOrder(Order o);
	public Order getOneById(Order o);
	public List<Order> getRentalAll(Order o);
	public List<Order> getLesseeAll(Order o);
	public boolean createOne(Order o);
	public List<Order> getNearAll(Order o);
	public String lesseechoose(Order o);
	public String rentchoose(Order o);
	public Set<String> rentchoosestatus(Order o);
	public String rentchoosealessee(Order o);
	public boolean confirmOne(Order o);
}

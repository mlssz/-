package dao;

import java.sql.Timestamp;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Scope("prototype")
@Component("Order")
public class Order {

	private int id;
	private int rental;
	private int lessee;
	private Timestamp starttime;
	private Timestamp endtime;
	private String startplace;
	private double startplacex;
	private double startplacey;
	private String endplace;
	private double fee;
	private int score;
	private Timestamp accepttime;
	private Timestamp finishtime;
	private String remark;
	private int trucktype;
	private int status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRental() {
		return rental;
	}

	public void setRental(int rental) {
		this.rental = rental;
	}

	public int getLessee() {
		return lessee;
	}

	public void setLessee(int lessee) {
		this.lessee = lessee;
	}

	public Timestamp getStarttime() {
		return starttime;
	}

	public void setStarttime(Timestamp starttime) {
		this.starttime = starttime;
	}


	public String getEndplace() {
		return endplace;
	}

	public void setEndplace(String endplace) {
		this.endplace = endplace;
	}

	public double getFee() {
		return fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public Timestamp getAccepttime() {
		return accepttime;
	}

	public void setAccepttime(Timestamp accepttime) {
		this.accepttime = accepttime;
	}

	public Timestamp getFinishtime() {
		return finishtime;
	}

	public void setFinishtime(Timestamp finishtime) {
		this.finishtime = finishtime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Timestamp getEndtime() {
		return endtime;
	}

	public void setEndtime(Timestamp endtime) {
		this.endtime = endtime;
	}

	public String getStartplace() {
		return startplace;
	}

	public void setStartplace(String startplace) {
		this.startplace = startplace;
	}

	public double getStartplacex() {
		return startplacex;
	}

	public void setStartplacex(double startplacex) {
		this.startplacex = startplacex;
	}

	public double getStartplacey() {
		return startplacey;
	}

	public void setStartplacey(double startplacey) {
		this.startplacey = startplacey;
	}

	public int getTrucktype() {
		return trucktype;
	}

	public void setTrucktype(int trucktype) {
		this.trucktype = trucktype;
	}
}

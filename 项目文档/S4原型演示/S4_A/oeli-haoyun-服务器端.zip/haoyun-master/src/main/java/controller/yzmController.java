package controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.ws.rs.core.MediaType;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import redis.clients.jedis.ShardedJedisPool;

@Controller
@RequestMapping("/yzm")
public class yzmController {

	@Autowired
	private ShardedJedisPool shardedJedisPool;

	@RequestMapping("/yuyin/{type}")
	public Map<String, Object> sendYuYin(@RequestParam(value = "phone") String phone,@PathVariable String type) {
		Map<String, Object> map = new HashMap<String, Object>();
		Random r = new Random(System.currentTimeMillis());
		String yzm = "";
		for (int i = 0; i < 6; i++) {
			yzm = yzm + (Math.abs(r.nextInt()) % 10);
		}
		String s = Send(yzm,phone);
		try {
			JSONObject jsonObj = new JSONObject(s);
			int error_code = jsonObj.getInt("error");
			String error_msg = jsonObj.getString("msg");
			if (error_code == 0) {
				map.put("status", 1);
			} else {
				map.put("status", 0);
				map.put("msg", error_msg);
			}
		} catch (JSONException ex) {
			ex.printStackTrace();
		}
		shardedJedisPool.getResource().set(phone+type, yzm);
		return map;
	}
	
	private String Send(String yzm,String phone) {
		Client client = Client.create();
		client.addFilter(new HTTPBasicAuthFilter("api", "1e8f0938eee68f351e661b27fb821b8e"));
		WebResource webResource = client.resource("http://voice-api.luosimao.com/v1/verify.json");
		MultivaluedMapImpl formData = new MultivaluedMapImpl();
		formData.add("mobile", phone);
		formData.add("code", yzm);
		ClientResponse response = webResource.type(MediaType.APPLICATION_FORM_URLENCODED).post(ClientResponse.class,
				formData);
		String textEntity = response.getEntity(String.class);
		return textEntity;
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}
}

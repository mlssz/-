package serviceimpl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import dao.Truck;
import service.truckService;


@Scope("prototype")
@Service("truckServiceImpl")
public class truckServiceImpl implements truckService {
	
	@Autowired
	private Truck tk;
	
	@Autowired
	private SqlSessionFactory ssf;

	public Truck getTk() {
		return tk;
	}

	public void setTk(Truck tk) {
		this.tk = tk;
	}

	public SqlSessionFactory getSsf() {
		return ssf;
	}

	public void setSsf(SqlSessionFactory ssf) {
		this.ssf = ssf;
	}

	public Truck addaTruck(Truck t) {
		SqlSession session = ssf.openSession();
		try{
			session.insert("insertatruck",t);
			session.commit();
		}catch(Exception e){
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return t;
	}

	public List<Truck> findMyTruck(Truck t) {
		SqlSession session = ssf.openSession();
		List<Truck> trucks = null;
		try{
			trucks = session.selectList("selecttruckbylessee", t);
		}catch(Exception e){
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return trucks;
	}

}

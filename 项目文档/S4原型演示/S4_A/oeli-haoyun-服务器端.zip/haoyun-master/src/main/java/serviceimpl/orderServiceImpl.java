package serviceimpl;

import java.util.List;
import java.util.Set;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import dao.Lessee;
import dao.Order;
import redis.clients.jedis.ShardedJedisPool;
import service.orderService;

@Scope("prototype")
@Service("orderServiceImpl")
public class orderServiceImpl implements orderService {

	@Autowired
	private SqlSessionFactory ssf;
	
	@Autowired
	private ShardedJedisPool shardedJedisPool;

	public Order getOneOrder(Order o) {
		List<Order> ls = null;
		SqlSession session = ssf.openSession();
		try {
			ls = session.selectList("selectOneOrder", o);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (ls != null) {
			return (Order) ls.get(0);
		}
		return null;
	}

	public List<Order> getOneUserAllOrders(Order o) {
		List<Order> ls = null;
		SqlSession session = ssf.openSession();
		try {
			ls = session.selectList("selectOneUserAllOrders", o);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return ls;
	}

	@SuppressWarnings("deprecation")
	public Order insertOneOrder(Order o) {
		SqlSession session = ssf.openSession();
		int mark = 0;
		List<Order> os = null;
		try {
			mark = session.insert("insertOneOrder", o);
			if (mark > 0) {
				o.setRemark(o.getStarttime().toLocaleString());
				os = session.selectList("selectOneOrderBytimeandrental",o);
			}
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (os.size() > 0)
			return os.get(0);
		else
			return null;
	}

	public boolean updateOneOrder(Order o) {
		SqlSession session = ssf.openSession();
		int mark = 0;
		try {
			mark = session.update("updateOneOrder", o);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (mark > 0)
			return true;
		else
			return false;
	}

	public boolean deleteOneOrder(Order o) {
		SqlSession session = ssf.openSession();
		int mark = 0;
		try {
			mark = session.delete("deleteaLineById", o);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (mark > 0)
			return true;
		else
			return false;
	}

	public SqlSessionFactory getSsf() {
		return ssf;
	}

	public void setSsf(SqlSessionFactory ssf) {
		this.ssf = ssf;
	}

	public Order getOneById(Order o) {
		SqlSession session = ssf.openSession();
		List<Order> os = null;
		try {
			os = session.selectList("selectOneOrder", o);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (os.isEmpty()) {
			return null;
		} else {
			return os.get(0);
		}
	}

	public List<Order> getRentalAll(Order o) {
		SqlSession session = ssf.openSession();
		List<Order> os = null;
		try {
			os = session.selectList("selectOneRentalAllOrders", o);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return os;
	}

	public List<Order> getLesseeAll(Order o) {
		SqlSession session = ssf.openSession();
		List<Order> os = null;
		try {
			os = session.selectList("selectOneLesseeAllOrders", o);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return os;
	}

	public boolean createOne(Order o) {
		SqlSession session = ssf.openSession();
		int mark = 0;
		try {
			mark = session.insert("insertOneOrder",o);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (mark > 0)
			return true;
		else
			return false;
	}

	public List<Order> getNearAll(Order o) {
		SqlSession session = ssf.openSession();
		List<Order> os = null;
		try {
			os = session.selectList("selectnearall", o);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return os;
	}

	public boolean confirmOne(Order o) {
		SqlSession session = ssf.openSession();
		int mark = 0;
		try {
			Order oo = session.selectOne("selectOneOrder",o);
			if (oo.getStatus() != 3) {
				return false;
			}
			mark = session.update("confirmOneOrder", o);
			session.commit();
			if (mark > 0 && o != null) {
				session.update("updatelesseeordercount",oo.getLessee());
			} else {
				session.rollback();
				mark = 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (mark > 0)
			return true;
		else
			return false;
	}

	@Override
	public synchronized String lesseechoose(Order o) {
		String msg = null;
		SqlSession session = ssf.openSession();
		int mark = 0;
		List<Order> os = null;
		try {
			os = session.selectList("selectOneOrder",o);
			if (os != null && os.size() > 0) {
				Order oo = os.get(0);
				if (oo.getStatus() == 0) {
					mark = session.update("acceptOneOrder",o);
					session.commit();
					if (mark > 0) {
						msg = null;
					} else {
						msg = "更新数据失败";
					}
				} else if (oo.getStatus() == 3) {
					msg = "该订单已被接单";
				} else {
					msg = "该订单已完成或当前操作非法";
				} 
			} else {
				msg = "订单不存在";
			}
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return msg;
	}

	@Override
	public synchronized String rentchoose(Order o) {
		SqlSession session = ssf.openSession();
		String msg = null;
		List<Lessee> ls = null;
		try {
			ls = session.selectList("selectalesseebyid",o.getLessee());
			if (ls != null && ls.size() > 0) {
				Lessee l = ls.get(0);
				List<Order> os = session.selectList("selectOneOrder",o);
				if (os != null && os.size() > 0) {
					Order oo = os.get(0);
					if (oo.getStatus() == 1) {
						if (shardedJedisPool != null) {
							ObjectMapper objectMapper = new ObjectMapper();
							long ii = shardedJedisPool.getResource().sadd("order"+o.getId(),objectMapper.writeValueAsString(l));
							if (ii <= 0) {
								msg = "redis操作失败或者已经存在";
							}
						} else {
							msg = "连接redis出错";
						}
					} else {
						msg = "抢订单失败，已经结束";
					}
				}
			} else {
				msg = "用户不存在";
			}
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return msg;
	}
	
	public Set<String> rentchoosestatus(Order o) {
		if (shardedJedisPool != null) {
			return shardedJedisPool.getResource().smembers("order"+o.getId());
		} else {
			return null;
		}
	}
	
	public String rentchoosealessee(Order o) {
		SqlSession session = ssf.openSession();
		String msg = null;
		try {
			List<Order> lo = session.selectList("selectOneOrder",o);
			if (lo != null && lo.size() > 0) {
				Order oo = lo.get(0);
				if (oo.getStatus() == 3) {
					if (oo.getLessee() == o.getLessee()) {
						msg = "你已经接单";
					} else {
						msg = "订单已被接";
					}
				}else if (oo.getRental() == o.getRental()) {
					int mark = session.update("acceptOneOrder",o);
					if (mark <= 0) {
						msg = "操作失败";
					} else {
						if (shardedJedisPool != null) {
							shardedJedisPool.getResource().del("order"+o.getId());
						}
					}
				} else {
					msg = "该订单的发起方不是你";
				}
			} else {
				msg = "数据库没有相关记录";
			}
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return msg;
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

}

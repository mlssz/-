package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("file")
public class fileupload {
	// 通过Spring的autowired注解获取spring默认配置的request
	@Autowired
	private HttpServletRequest request;

	/***
	 * 上传文件 用@RequestParam注解来指定表单上的file为MultipartFile
	 * 
	 * @param file
	 * @return
	 */
	@RequestMapping("upload")
	public String fileUpload(@RequestParam("file") MultipartFile file) {
		long start = System.currentTimeMillis();
		// 判断文件是否为空
		if (!file.isEmpty()) {
			try {
				// 文件保存路径
				String filePath = request.getSession().getServletContext().getRealPath("/") + "temp/"
						+ file.getOriginalFilename();
				// 转存文件
				file.transferTo(new File(filePath));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		long stop = System.currentTimeMillis();
		System.out.println("时间: " + (stop - start));
		// 重定向
		return "redirect:list.json";
	}

	@RequestMapping("/download")
	public void downloadFile(@RequestParam("fileName") String fileName, HttpServletResponse response) {
		response.setCharacterEncoding("utf-8");
		try {
			// 文件保存路径
			String filePath = request.getSession().getServletContext().getRealPath("/") + "temp/";
			File file = new File(filePath + fileName);
			if (!file.exists()) {
				PrintWriter out = response.getWriter();
				out.print("Not Found !");
				out.close();
				return;
			}
			Path path = Paths.get(file + fileName);
			response.setContentType(Files.probeContentType(path));
			response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
			response.addHeader("Content-Length", "" + file.length());
			InputStream inputStream = new FileInputStream(file);
			System.out.println(file);
			OutputStream os = response.getOutputStream();
			byte[] b = new byte[1024];
			int length;
			while ((length = inputStream.read(b)) > 0) {
				os.write(b, 0, length);
			}
			inputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/***
	 * 读取上传文件中得所有文件并返回
	 * 
	 * @return
	 */
	@RequestMapping("list")
	public Map<String, Object> list() {
		String filePath = request.getSession().getServletContext().getRealPath("/") + "upload/";
		Map<String, Object> map = new HashMap<String, Object>();
		File uploadDest = new File(filePath);
		String[] fileNames = uploadDest.list();
		map.put("files", fileNames);
		return map;
	}
}

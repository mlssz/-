package serviceimpl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import dao.Lessee;
import service.lesseeService;

@Scope("prototype")
@Service("lesseeServiceImpl")
public class lesseeServiceImpl implements lesseeService {

	@Autowired
	private Lessee le;

	@Autowired
	private SqlSessionFactory sqlSessionFactory;

	public Lessee getLe() {
		return le;
	}

	public void setLe(Lessee le) {
		this.le = le;
	}

	public SqlSessionFactory getSqlSessionFactory() {
		return sqlSessionFactory;
	}

	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		this.sqlSessionFactory = sqlSessionFactory;
	}

	public Lessee getLessee(Lessee l) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			List<Lessee> ls = session.selectList("selectlesseebyaccount", l);
			if (ls.isEmpty()) {
				session.insert("insertalesseeuser", l);
				session.insert("insertalessee", l);
				session.commit();
				le = session.selectOne("selectalesseebyaccountandtype", l);
			} else {
				le = ls.get(0);
				le.setType(-1);
			}
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
			le = null;
		} finally {
			session.close();
		}
		return le;
	}

	public Lessee getLesseeByaccountandpasswd(Lessee l) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			List<Lessee> ls = session.selectList("selectlesseebyaccountandpasswd", l);
			if (ls.isEmpty()) {
				le = null;
			} else {
				le = ls.get(0);
				if (le.getPassword().equals(l.getPassword())) {
					session.update("updatelesseepositionbyid", l);
					session.update("updatelesseelogintimebyid", l);
					session.commit();
				} else {
					le.setType(-1);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
			le = null;
		} finally {
			session.close();
		}
		return le;
	}

	public Lessee updateLesseeById(Lessee l) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			session.update("updatelesseeinfo1", l);
			session.update("updatelesseeinfo2", l);
			session.commit();
			le = session.selectOne("selectalesseebyid",l);
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
			le = null;
		} finally {
			session.close();
		}
		return le;
	}

}

package controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import dao.Line;
import service.lineService;

@Controller
@RequestMapping("line")
public class lineController {

	private lineService ls = null;

	@RequestMapping("getAllByUserId")
	public Map<String, Object> getAllLineByUserId(@RequestParam("uid") int id) {
		Line l = new Line();
		Map<String, Object> json = new HashMap<String, Object>();
		l.setRental(id);
		List<Line> os = ls.getAllLineByUserId(l);
		if (os.size() > 0) {
			json.put("status", 1);
			json.put("lines", os);
		} else {
			json.put("status", 0);
			json.put("msg", "找不到记录");
		}
		return json;
	}

	@RequestMapping("getOneById")
	public Map<String, Object> getaLineById(@RequestParam("id") int id) {
		Map<String, Object> json = new HashMap<String, Object>();
		Line l = new Line();
		l.setId(id);
		l = ls.getaLineById(l);
		if (l != null) {
			json.put("status", 1);
			json.put("line", l);
		} else {
			json.put("status", 0);
			json.put("msg", "找不到记录");
		}
		return json;
	}

	@RequestMapping("deleteOneById")
	public Map<String, Object> deleteaLineById(@RequestParam("id") int id) {
		Map<String, Object> json = new HashMap<String, Object>();
		Line l = new Line();
		l.setId(id);
		boolean b = ls.deleteaLineById(l);
		if (b) {
			json.put("status", 1);
		} else {
			json.put("status", 0);
			json.put("msg", "删除失败");
		}
		return json;
	}

	@RequestMapping("updateOneById")
	public Map<String, Object> updateaLineById(@RequestParam("id") int id, @RequestParam("rental") int rental,
			@RequestParam("lessee") int lessee, @RequestParam("startplace") String startplace,
			@RequestParam("endplace") String endplace, @RequestParam("center") String center,
			@RequestParam("remark") String remark) {
		Map<String, Object> json = new HashMap<String, Object>();
		Line l = new Line();
		l.setId(id);
		l.setRental(rental);
		l.setLessee(lessee);
		l.setStartplace(startplace);
		l.setEndplace(endplace);
		l.setCenter(center);
		l.setCreatetime(new Timestamp(System.currentTimeMillis()));
		l.setRemark(remark);
		boolean b = ls.updateaLineById(l);
		if (b) {
			json.put("status", 1);
		} else {
			json.put("status", 0);
			json.put("msg", "更新失败");
		}
		return json;
	}

	@RequestMapping("insertOne")
	public Map<String, Object> insertaLine(@RequestParam("rental") int rental, @RequestParam("lessee") int lessee,
			@RequestParam("startplace") String startplace, @RequestParam("endplace") String endplace,
			@RequestParam("center") String center, @RequestParam("remark") String remark) {
		Map<String, Object> json = new HashMap<String, Object>();
		Line l = new Line();
		l.setRental(rental);
		l.setLessee(lessee);
		l.setStartplace(startplace);
		l.setEndplace(endplace);
		l.setCenter(center);
		l.setCreatetime(new Timestamp(System.currentTimeMillis()));
		l.setRemark(remark);
		boolean b = ls.updateaLineById(l);
		if (b) {
			json.put("status", 1);
		} else {
			json.put("status", 0);
			json.put("msg", "插入数据库失败");
		}
		return json;
	}

	public lineService getLs() {
		return ls;
	}

	@Resource
	public void setLs(lineService ls) {
		this.ls = ls;
	}

}

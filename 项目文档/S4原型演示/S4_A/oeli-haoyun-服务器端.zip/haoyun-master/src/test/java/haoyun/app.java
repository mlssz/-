package haoyun;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class app {

	private users u;

	public void setU(users u) {
		this.u = u;
	}

	public void show() {
		System.out.println(u.getName());
		System.out.println(u.getAge());
	}

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] { "app.xml" });
		app a = context.getBean("app", app.class);
		a.show();
		context.close();
	}
}